def correct_answer():
    print('Correct!')


def game_success_finish(name):
    print('Congratulations, ', name, '!', sep='')


def try_again(name):
    print("Let's try again, ", name, "!", sep='')

