# CodeClimate Maintainability
[![Maintainability](https://api.codeclimate.com/v1/badges/5e5597a68a3fd9bd440f/maintainability)](https://codeclimate.com/github/alabarym/python-project-lvl1/maintainability)
# CodeClimate test coverage
[![Test Coverage](https://api.codeclimate.com/v1/badges/5e5597a68a3fd9bd440f/test_coverage)](https://codeclimate.com/github/alabarym/python-project-lvl1/test_coverage)
# travis ci
[![Build Status](https://travis-ci.com/alabarym/python-project-lvl1.svg?branch=master)](https://travis-ci.com/alabarym/python-project-lvl1)
# asciinema: brain-games brain-even
https://asciinema.org/a/nXTbcSbtql2NXpV1edZi0POIi
# asciinema: brain-calc
https://asciinema.org/a/aA7CoVuGeXxsU9iaJBjPHpilo
# asciinema: brain-gdc
https://asciinema.org/a/gCn5l27ClWDhbfdGY5wbFOAK8
# asciinema: brain-progression
https://asciinema.org/a/JPKROcOUfDbYedkCZ47qE0v1H
# asciinema: brain-prime
https://asciinema.org/a/ut7f5bqDzWlYMJT0lKSNOG57u
